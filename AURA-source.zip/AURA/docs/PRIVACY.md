# Privacy and local data

AURA processes microphone sound on your Android phone and plays the result through headphones. It does not record microphone audio to a file, upload conversations, contact an inference API, or require an account. The app has no internet permission, advertising SDK, or analytics service.

## Permissions

- **Microphone:** required for live listening. If you deny access, you can still browse the interface and settings, but microphone listening cannot start.
- **Modify audio settings:** lets the app configure its own audio session and request the intended headphone route.
- **Foreground service:** lets Android represent active listening with a persistent service notification. Stop listening from the app or notification.
- **Notifications, where requested by Android:** make the active service and its Stop action easier to access. Notification behavior differs across Android versions.
- **Documents selected by you:** Android's document picker grants access to the specific backup file you choose. The app does not need broad access to all phone storage.

Android may show a microphone privacy indicator while listening. Stopping a session releases microphone and playback resources. Device-specific interruption and background behavior should be checked using the [validation checklist](VALIDATION.md).

## Stored locally

AURA stores preferences, up to 20 saved profiles, and up to 200 recent session records on the phone. The Android manifest disables automatic app-data backup; the explicit JSON export is the supported backup path. Session records contain metadata, ratings, and optional written notes; they do not contain microphone audio. Avoid entering sensitive conversation details into notes if you do not want those details included in a later backup.

The app's private storage benefits from the normal Android device protections. This is not a promise of an independently audited encrypted vault. Use your phone's screen lock and regular security updates.

## Export and import

A JSON export includes saved app data such as preferences, profiles, and session feedback. It is a readable file. It is not a microphone recording or an encrypted archive.

You choose where to save it using Android's document picker. A local folder keeps it on the phone; a cloud provider you select may upload it according to that provider's settings. AURA does not create or manage a storage account for you.

Only restore backups you trust. Invalid or incompatible files are rejected before import. Import accepts AURA version 1 JSON backups of at most 1 MB and replaces settings, profiles, and session history rather than merging them. Export your current data before restoring another backup if you need to keep both versions.

## Delete data

Use the app's reset option to remove the local settings and history managed by the app. Android's **Settings → Apps → AURA → Storage → Clear storage** or uninstalling AURA removes internal app data as well. Delete exported backup files separately from the locations you saved them to.

Build tools may download dependencies during development. That development traffic is separate from the installed app, which works offline.
