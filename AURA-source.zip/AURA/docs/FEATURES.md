# Purpose and feature scope

AURA's source documents describe assistive listening: making speech easier to follow in noisy environments while keeping some awareness of surroundings. They propose Voice Focus, Care/Focus/Commute modes, personal preferences, session feedback, and local processing. The provided image supplies the navy and pale-blue visual direction.

The requested implementation is the user's chosen free, offline native Android first version. Any document suggestions involving commercial subscriptions, paid services, research claims, or future AI capabilities are product context, not instructions to buy services or claim those features have been achieved.

## What the app displays and uses

- Current listening state and audio-route information.
- Microphone permission and headphone availability.
- The selected listening mode and current audio settings.
- Saved profiles and their listening preferences.
- Session metadata, ratings, and optional feedback notes.
- Local backup, restore, reset, privacy, and installation guidance.

The output gain is attenuation-only: this version is not a high-gain hearing amplifier. There is no login, remote user database, cloud inference, analytics endpoint, or runtime API key. The Android package does not need internet permission. All live audio processing runs locally.

## Implemented first-version approach

| Area | Behavior | Practical limit |
| --- | --- | --- |
| Speech enhancement | Speech-oriented filtering and adjustable EQ emphasize useful frequency ranges. | It can affect all voices and other sounds in those bands; it cannot identify the intended speaker. |
| Noise reduction | A local adaptive expander reduces some quieter background sound; Android device noise suppression is used when available and reduction is enabled. | Loud, changing noise and competing speech remain difficult. Strong settings may soften speech or introduce artifacts. |
| Listening modes | Care, Focus, and Commute provide convenient control presets. | Presets are not medical hearing profiles or scientifically calibrated environments. |
| Awareness | A controllable surroundings mix keeps some microphone sound from before the app's speech filtering and expansion. | Android's device noise suppressor may already have processed this sound. The mix does not recognize sirens, alarms, vehicles, or emergency events and cannot guarantee audibility. |
| Output dynamics | Attenuation-only gain, compression, and a digital sample peak cap help manage output levels. | Headphone loudness depends on system volume and hardware. A sample cap is not a hearing-safety guarantee. |
| Profiles | Users save and recall up to 20 listening profiles locally. | The app does not perform an audiogram, diagnose hearing loss, or train a personalized AI model. |
| Feedback | Local session metadata, ratings, and notes help users compare settings. Users can explicitly apply simple rule-based setting suggestions. | Feedback is not uploaded, does not train a model, and does not automatically change settings. |
| Background operation | Native microphone processing uses a foreground service and an ongoing notification. Audio-focus loss, headphone disconnection, and route changes stop listening; restart is deliberate. | Device policies and manufacturer power management may interrupt it. Route checks cannot guarantee that Android will never make a brief transition before notifying the app. |
| Backup | AURA settings and feedback can be exported/imported as version 1 JSON using the Android document picker. Import validates at most 1 MB before replacing local data. | Import replaces, rather than merges, settings, profiles, and history. Backups are ordinary files, not end-to-end encrypted cloud sync. |

## Deliberately unclaimed capabilities

- **Selected-speaker AI isolation:** no voice enrollment, speaker identity model, or separation model is included.
- **Reliable emergency-sound preservation:** awareness is a mix setting, not sound classification.
- **A guaranteed latency such as under 100 ms:** latency must be measured on real device/headphone combinations, particularly with Bluetooth. The displayed Processing time is DSP computation time for one block, not end-to-end latency.
- **Clinical effectiveness:** the implementation has no medical certification and is not a replacement for professional hearing care or a fitted hearing aid.
- **Recordings or live transcription:** no microphone recordings or speech-to-text service are included.
- **System-wide processing:** the app monitors its own microphone stream; it cannot transparently rewrite all Android app audio.

## Free paths for future development

No paid alternative is needed to use the first version. Future research can evaluate open-source noise-reduction models, such as RNNoise, and on-device inference runtimes. Each specific model and dataset still needs license review, device-performance testing, integration work, and listening evaluation. A free model is not automatically suitable for live hearing assistance or selected-speaker isolation.

Optional future features such as local transcription can also use offline models, at the cost of larger downloads, more memory, battery use, and device compatibility work. Any later feature that sends audio off-device should require an explicit product and privacy decision rather than silently replacing the current offline behavior.
